*** LeaCoin (LEA) ***

- Algorithm: SHA256
- 2,000,000,000 total coins
- 1,051,898,000 Coins will be mined in 5 years
- Premine: 0.5%
- Block target: 30 seconds
- Difficulty change target: 2 blocks
- Reward Type: PoW
- Block reward:
  -- 200 LEA/block for the first 5 years
  --  20 LEA/block after 5,259,490 blocks (~5 years),
    until the total number of coins reaches 2 billion - in approx. 45 years :-)

- Mined block confirmations: 120
- Transaction confirmations: 6

- P2P Port: 18123
- RPC Port: 18124

leacoin.conf:

	rpcuser=YOUR_RPC_USER
	rpcpassword=YOUR_RPC_PASSWORD
	rpcallowip=127.0.0.1
	server=1
	daemon=1
	listen=1

- Mining pool: https://www.mpool.me/lea/
- Block Crawler: https://www.mpool.me/bc/lea/
- Paper Wallet Generator: https://www.mpool.me/wg/lea/
